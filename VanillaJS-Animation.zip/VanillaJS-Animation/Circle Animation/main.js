var ol = 0;
var isPlaying = false;
var circleInterval;

var el = document.getElementById("circle");
var scale = 1;

function circleAnimation(time) {
    ol++;
    scale++;
    el.style.left = ol + "px";
    el.style.width = scale + "px";
    el.style.height = scale + "px";
    el.style.borderRadius = scale * 100 + "px";
    circleInterval = requestAnimationFrame(circleAnimation);
    
}

function mouseClicked() {
    if(isPlaying){
        isPlaying = false;
        document.getElementById("circle").style.background = "dimgrey";
        cancelAnimationFrame(circleInterval);
    }else{
        isPlaying = true;
        document.getElementById("circle").style.background = "brown";
        circleInterval = requestAnimationFrame(circleAnimation);
    }
}

document.getElementById("circle").addEventListener("click", mouseClicked);
document.getElementById("circle").style.background = "dimgrey";